/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment_2;

/**
 *
 * @author obala
 */
public class Movie extends MediaItem{
    private String director;
    private int year;
    private int runtimeMinutes;
    
    public Movie(String id, String title, String director, int year, int runtimeMinutes){
        if(!((id.length() >= 3) && id.substring(0,3).equals("MV-"))){
            if(Integer.parseInt(id) < 10)
                id = "MV-00" + id;
            else if (Integer.parseInt(id) < 100)
                id = "MV-0" + id;
            else if(Integer.parseInt(id) < 1000)
                id = "MV-" + id;
        }
        super(id, title);
        this. director = director;
        this.year = year;
        this.runtimeMinutes = runtimeMinutes;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getRuntimeMinutes() {
        return runtimeMinutes;
    }

    public void setRuntimeMinutes(int runtimeMinutes) {
        this.runtimeMinutes = runtimeMinutes;
    }
    
    public String summary(){
        return "Movie," + id + "," + title + "," + director + "," + year + "," + runtimeMinutes + "\n";
    }
    
    @Override
    public String toString(){
        return "Movie: " + id + " Title: " + title + " Director: " + director + " Year: " + year + " Run time minutes: " + runtimeMinutes;
    }
}
