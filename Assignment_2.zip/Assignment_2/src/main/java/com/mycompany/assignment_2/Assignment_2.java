/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author obala
 */

enum BookVals{ITEM, ID, TITLE, AUTHOR, YEAR, PAGECOUNT};
enum MovieVals{ITEM, ID, TITLE, DIRECTOR, YEAR, RUNTIMEMINUTES};
enum AlbumVals{ITEM, ID, TITLE, ARTIST, YEAR, TRACKCOUNT};

public class Assignment_2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final String fileName = "Catalog.txt";
        int operation;
        ArrayList<MediaItem> mediaItems = new ArrayList<>();
        String answer = "yes";
        System.out.println("Welcome to the media catalog");
        
        final String DELIMIT = ",";
        
        try(BufferedReader br = new BufferedReader(new FileReader(fileName))){
        
            String line = br.readLine();
        
            while(line != null){
            
                String[] parts = line.split(DELIMIT);
                switch(parts[BookVals.ITEM.ordinal()]){
                    case "Book": 
                        
                        String id = parts[BookVals.ID.ordinal()];
                        String title = parts[BookVals.TITLE.ordinal()];
                        String author = parts[BookVals.AUTHOR.ordinal()];
                        int year = Integer.parseInt(parts[BookVals.YEAR.ordinal()]);
                        int pageCount = Integer.parseInt(parts[BookVals.PAGECOUNT.ordinal()]);

                        MediaItem book = new Book(id,title,author,year,pageCount);
                        mediaItems.add(book);
                        break;
                    
                    case "Movie":
                        id = parts[MovieVals.ID.ordinal()];
                        title = parts[MovieVals.TITLE.ordinal()];
                        String director = parts[MovieVals.DIRECTOR.ordinal()];
                        year = Integer.parseInt(parts[MovieVals.YEAR.ordinal()]);
                        int runtimeMinutes = Integer.parseInt(parts[MovieVals.RUNTIMEMINUTES.ordinal()]);

                        MediaItem movie = new Movie(id,title,director,year,runtimeMinutes);
                        mediaItems.add(movie);
                        break;
                    case "Album":
                        id = parts[AlbumVals.ID.ordinal()];
                        title = parts[AlbumVals.TITLE.ordinal()];
                        String artist = parts[AlbumVals.ARTIST.ordinal()];
                        year = Integer.parseInt(parts[AlbumVals.YEAR.ordinal()]);
                        int trackCount = Integer.parseInt(parts[AlbumVals.TRACKCOUNT.ordinal()]);

                        MediaItem album = new Album(id,title,artist,year,trackCount);
                        mediaItems.add(album);
                        break;
                }
                line = br.readLine();
            }
        }catch (FileNotFoundException e) {
        System.out.println("File not found: " + fileName);
    } catch (IOException e) {
        System.out.println("Unable to read file: " + fileName);
    }      
        
        while(answer.equals("yes") || answer.equals("Yes")){
            System.out.println("Choose the operation you want to perform:");
            System.out.println("1) List all items\n" +
                "2) Add item (Book/Movie/Album)\n" +
                "3) Save catalog to CSV\n" +
                "4) Export catalog to binary file (catalog.bin)\n" +
                "0) Exit");
            operation = scanner.nextInt();
            switch(operation){
                case 1:
                    if(mediaItems.size() != 0){
                        for( MediaItem mediaItem : mediaItems){
                            System.out.println(mediaItem);
                        }
                    }
                    else System.out.println("List is empty!");
                    break;
                case 2:
                    System.out.println("What item would you like to add?");
                    System.out.println("1) Book\n" + "2) Movie\n" + "3) Album");
                    int addOperation = scanner.nextInt();
                    switch(addOperation){
                        case 1:
                            System.out.println("Please enter id(number)");
                            String id = String.valueOf(scanner.nextInt());
                            System.out.println("Please enter title");
                            scanner.nextLine();//clears the buffer
                            String title = scanner.nextLine();
                            System.out.println("Please enter author");
                            String author = scanner.nextLine();
                            System.out.println("Please enter year");
                            int year = scanner.nextInt();
                            System.out.println("Please enter pageCount");
                            int pageCount = scanner.nextInt();
                            
                            MediaItem book = new Book(id,title,author,year,pageCount);
                            mediaItems.add(book);
                            break;
                        case 2: 
                            System.out.println("Please enter id(number)");
                            id = String.valueOf(scanner.nextInt());
                            System.out.println("Please enter title");
                            scanner.nextLine();//clears the buffer
                            title = scanner.nextLine();
                            System.out.println("Please enter director");
                            String director = scanner.nextLine();
                            System.out.println("Please enter year");
                            year = scanner.nextInt();
                            System.out.println("Please enter tun time minutes");
                            int runtimeMinutes = scanner.nextInt();
                            
                            MediaItem movie = new Movie(id,title,director,year,runtimeMinutes);
                            mediaItems.add(movie);
                            break;
                        case 3:
                            System.out.println("Please enter id(number)");
                            id = String.valueOf(scanner.nextInt());
                            System.out.println("Please enter title");
                            scanner.nextLine();//clears the buffer
                            title = scanner.nextLine();
                            System.out.println("Please enter artist");
                            String artist = scanner.nextLine();
                            System.out.println("Please enter year");
                            year = scanner.nextInt();
                            System.out.println("Please enter track count");
                            int trackCount = scanner.nextInt();
                            
                            MediaItem album = new Album(id,title,artist,year,trackCount);
                            mediaItems.add(album);
                            break;
                    }
                    
                    break;
                case 3:
                    System.out.println("Trying to save the catalog...");
                    try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName)))){
                        for(MediaItem mediaItem : mediaItems){
                            out.write(mediaItem.summary());
                        }
                            System.out.println("succesfully saved!");
                        
                    }catch(Exception e){
                        System.out.println("Wasn't able to save catalog!");
                    }
                    break;
                case 4:
                    System.out.println("Trying to save the catalog to binary file...");
                    try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("Catalog.bin")))){
                        for(MediaItem mediaItem : mediaItems){
                            out.write(mediaItem.summary());
                        }
                            System.out.println("succesfully saved!");
                        
                    }catch(Exception e){
                        System.out.println("Wasn't able to save catalog to binary file!");
                    }
                    break;
                case 0:
                    answer = "no";
                    System.out.println("Trying to save the catalog automaticly...");
                    try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("Catalog.txt")))){
                        for(MediaItem mediaItem : mediaItems){
                            out.write(mediaItem.summary());
                        }
                            System.out.println("Succesfully saved!");
                        
                    }catch(Exception e){
                        System.out.println("Wasn't able to save catalog!");
                    }
                    
                    break;
            }
        }
    }

    private static Reader FileReader(String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


