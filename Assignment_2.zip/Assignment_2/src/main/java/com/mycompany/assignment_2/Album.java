/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment_2;

/**
 *
 * @author obala
 */
public class Album extends MediaItem{
    private String artist;
    private int year;
    private int trackCount;
    
    public Album(String id, String title, String artist, int year, int trackCount){
        if(!((id.length() >= 3) && id.substring(0,3).equals("AL-"))){
            if(Integer.parseInt(id) < 10)
                id = "AL-00" + id;
            else if (Integer.parseInt(id) < 100)
                id = "AL-0" + id;
            else if(Integer.parseInt(id) < 1000)
                id = "AL-" + id;
        }
        super(id, title);
        this.artist = artist;
        this.year = year;
        this.trackCount = trackCount;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getTrackCount() {
        return trackCount;
    }

    public void setTrackCount(int trackCount) {
        this.trackCount = trackCount;
    }
    
    public String summary(){
    return "Album," + id + "," + title + "," + artist + "," + year + "," + trackCount + "\n";
    }
    @Override
    public String toString(){
        return "Album: " + id + " Title: " + title + " Artist: " + artist + " Year: " + year + " Track Count: " + trackCount;
    }
}

