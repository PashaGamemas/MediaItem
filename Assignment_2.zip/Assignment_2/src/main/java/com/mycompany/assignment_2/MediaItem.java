/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment_2;

/**
 *
 * @author obala
 */
public abstract class MediaItem {
    public String id;
    public String title;
    
    public MediaItem(String id, String title){
        this.id = id;
        this.title = title;
    }
    
    public String getId(){
    return id;
    }
    
    public void setId(String id){
    this. id = id;
    }
    
    public String getTitle(){
    return title;
    }
    
    public void setTitle(String title){
    this.title = title;
    }
    
    public abstract String summary();
    
}
