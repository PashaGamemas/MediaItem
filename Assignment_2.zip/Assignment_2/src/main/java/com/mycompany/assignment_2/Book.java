/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment_2;

/**
 *
 * @author obala
 */
public class Book extends MediaItem{
    private String author;
    private int year;
    private int pageCount;
    
    public Book(String id, String title,String author, int year, int pageCount){
        if(!((id.length() >= 3) && id.substring(0,3).equals("BK-"))){
            if(Integer.parseInt(id) < 10)
                id = "BK-00" + id;
            else if (Integer.parseInt(id) < 100)
                id = "BK-0" + id;
            else if(Integer.parseInt(id) < 1000)
                id = "BK-" + id;
        }
        super(id,title);
        this.author = author;
        this.year = year;
        this.pageCount = pageCount;
    }
    
    public String summary(){
    return "Book," + id + "," + title + "," + author + "," + year + "," + pageCount + "\n";
    }
    
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
    @Override
    public String toString(){
        return "Book: " + id + " Title: " + title + " Author: " + author + " Year: " + year + " Page Count: " + pageCount;
    }
}
